// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.util;

@FunctionalInterface
public interface TripleFunction<A,B,C,R> {
  R fun(A a, B b, C c);
}
