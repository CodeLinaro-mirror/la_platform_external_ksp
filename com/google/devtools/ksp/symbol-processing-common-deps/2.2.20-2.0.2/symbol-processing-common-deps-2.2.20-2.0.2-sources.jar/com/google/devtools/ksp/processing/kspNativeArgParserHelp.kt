package com.google.devtools.ksp.processing

fun kspNativeArgParserHelp(): String = """
*   -target=String
*   -module-name=String
*   -source-roots=List<File>
    -common-source-roots=List<File>
    -libraries=List<File>
    -friends=List<File>
    -processor-options=Map<String, String>
*   -project-base-dir=File
*   -output-base-dir=File
*   -caches-dir=File
*   -class-output-dir=File
*   -kotlin-output-dir=File
*   -resource-output-dir=File
    -incremental=Boolean
    -incremental-log=Boolean
    -modified-sources=List<File>
    -removed-sources=List<File>
    -changed-classes=List<String>
*   -language-version=String
*   -api-version=String
    -all-warnings-as-errors=Boolean
    -map-annotation-arguments-in-java=Boolean
*   <processor classpath>
"""
