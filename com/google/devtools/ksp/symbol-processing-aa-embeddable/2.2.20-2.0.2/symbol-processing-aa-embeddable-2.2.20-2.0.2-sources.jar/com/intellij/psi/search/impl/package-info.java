// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
@ApiStatus.Internal
package ksp.com.intellij.psi.search.impl;

import ksp.org.jetbrains.annotations.ApiStatus;