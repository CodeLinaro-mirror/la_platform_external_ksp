// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package ksp.com.intellij.psi.tree.java;

import ksp.org.jetbrains.annotations.NonNls;

public class IKeywordElementType extends IJavaElementType {
  public IKeywordElementType(@NonNls String debugName) {
    super(debugName);
  }
}