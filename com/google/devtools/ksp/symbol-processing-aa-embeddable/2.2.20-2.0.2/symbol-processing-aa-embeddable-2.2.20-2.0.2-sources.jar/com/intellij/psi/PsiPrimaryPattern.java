// Copyright 2000-2021 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package ksp.com.intellij.psi;

import ksp.org.jetbrains.annotations.ApiStatus;

@ApiStatus.NonExtendable
public interface PsiPrimaryPattern extends PsiPattern {
}
