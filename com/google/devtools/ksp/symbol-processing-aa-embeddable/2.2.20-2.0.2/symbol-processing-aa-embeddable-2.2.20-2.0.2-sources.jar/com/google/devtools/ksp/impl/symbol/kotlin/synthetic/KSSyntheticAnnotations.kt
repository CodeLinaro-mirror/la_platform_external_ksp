package com.google.devtools.ksp.impl.symbol.kotlin.synthetic

import com.google.devtools.ksp.impl.ResolverAAImpl
import ksp.org.jetbrains.kotlin.analysis.api.KaImplementationDetail
import ksp.org.jetbrains.kotlin.analysis.api.impl.base.annotations.KaAnnotationImpl
import ksp.org.jetbrains.kotlin.analysis.api.platform.lifetime.KotlinAlwaysAccessibleLifetimeToken
import ksp.org.jetbrains.kotlin.name.ClassId

@OptIn(KaImplementationDetail::class)
fun getExtensionFunctionTypeAnnotation() = KaAnnotationImpl(
    ClassId.fromString(ExtensionFunctionType::class.qualifiedName!!),
    null,
    null,
    lazyOf(emptyList()),
    null,
    KotlinAlwaysAccessibleLifetimeToken(ResolverAAImpl.ktModule.project)
)
