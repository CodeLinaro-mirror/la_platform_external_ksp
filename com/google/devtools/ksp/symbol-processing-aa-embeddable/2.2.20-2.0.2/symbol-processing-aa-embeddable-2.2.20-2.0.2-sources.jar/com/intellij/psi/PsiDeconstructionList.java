// Copyright 2000-2022 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package ksp.com.intellij.psi;

import ksp.org.jetbrains.annotations.ApiStatus;
import ksp.org.jetbrains.annotations.NotNull;

/**
 * Represents elements between '(' and ')' (inclusive) in {@link PsiDeconstructionPattern}.
 */
@ApiStatus.Experimental
public interface PsiDeconstructionList extends PsiElement {
  @NotNull
  PsiPattern @NotNull [] getDeconstructionComponents();
}
