package com.google.devtools.ksp.gradle
val KSP_KOTLIN_BASE_VERSION = "2.2.20"
val KSP_VERSION = "2.2.20-2.0.2"
val KSP_COROUTINES_VERSION = "1.6.4"